DJ USB Tool - Linux Version
========================

Instructions:
1. Copy this entire folder to your USB drive
2. Right-click DJ_USB_Tool.sh and select 'Run as Program'
   or open terminal and run: ./DJ_USB_Tool.sh

Requirements:
- Python 3.6 or higher installed
- Python 'requests' package (run 'pip3 install requests' if needed)
