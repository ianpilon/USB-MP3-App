DJ USB Tool - Windows Version
===========================

Instructions:
1. Copy this entire folder to your USB drive
2. Double-click on DJ_USB_Tool.bat to start syncing

Requirements:
- Python 3.6 or higher installed
- Python 'requests' package (run 'pip install requests' if needed)
