DJ USB Tool - macOS Version
=========================

Instructions:
1. Copy this entire folder to your USB drive
2. Double-click on DJ_USB_Tool.command to start syncing
   (If it doesn't open, right-click and select Open)

Requirements:
- Python 3.6 or higher installed
- Python 'requests' package (run 'pip3 install requests' if needed)
